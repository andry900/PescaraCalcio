/* eslint-disable no-undef */
sap.ui.define([
],
    function (UriParameters) {
        return sap.ui.controller("pescaraCalcio.coach.pescarafe.ext.controller.ListReportExt", {


        })
    });